# Black-Jack
A visual game of black jack! Made with pygame.

Run the *main.py* script to get started.

# Game Controls
Press space to end beting period or to HIT (get another card). 
Press TAB to STAY.
Click on the chips on the left side of thr screen to place a bet.

# Requirements
- Python 3.x
- pygame

# Run in Gitpod

You can also run Sudoku-GUI-Solver in Gitpod, a free online dev environment for GitHub:

If you're intersted in a paid subscription with GitPod use the coupon code: TECHWITHTIM19

[![Open in Gitpod](https://gitpod.io/button/open-in-gitpod.svg)](https://gitpod.io/#https://github.com/techwithtim/Black-Jack/blob/master/main.py)
